
Alter PROCEDURE Save_Employee 
( 
	@p_Flag CHAR(1),
	@p_ID  INT,
	@p_Name VARCHAR(240),
	@p_Age INT,
	@p_Marital_Status VARCHAR(100),
	@p_Salary DECIMAL,
	@p_Location VARCHAR(240)
)
AS
    BEGIN
		DECLARE @v_ID INT
		SET @v_ID = @p_ID
		 BEGIN TRY
            
			BEGIN TRANSACTION  

			IF @p_Flag = 'I'
            BEGIN 
				
				INSERT INTO Employees 
									( Name ,
									  Age ,
									  Salary,
									  Location,
									  Marital_Status
									)
									VALUES(  @p_Name ,
											 @p_Age ,
											 @p_Salary ,
											 @p_Location,
											 @p_Marital_Status 
										  )
                
				SET @v_ID = @@IDENTITY
            END
			ELSE
				IF @p_Flag = 'E'
				BEGIN 

					UPDATE Employees SET Name = @p_Name,
										 Age = @p_Age,
										 Salary = @p_Salary,
										 Location = @p_Location,
										 Marital_Status = @p_Marital_Status
					WHERE ID = @p_ID

				END
				ELSE
					IF @p_Flag = 'D'
						BEGIN 

							DELETE Employees WHERE ID = @p_ID

						END

			COMMIT TRANSACTION  
			SELECT @v_ID
        END TRY 
        BEGIN CATCH
            ROLLBACK TRANSACTION  
            SELECT -1
        END CATCH
    END        


  
