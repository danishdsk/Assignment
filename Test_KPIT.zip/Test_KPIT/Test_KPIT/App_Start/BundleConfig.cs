﻿using System.Web;
using System.Web.Optimization;

namespace Test_KPIT
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            //js For Layout
            bundles.Add(new ScriptBundle("~/bundles/LayoutCommonJS").Include("~/Scripts/jquery-2.0.3.min.js",
                "~/Scripts/jquery.hotkeys-0.8.js",
                "~/assets/js/jquery-ui-1.10.3.full.min.js",
                "~/Scripts/bootstrap-typeahead.js",
                "~/Scripts/jQuery.hotKeyMap-1.0.js",
                "~/assets/js/dataTables/jquery.dataTables.js",
                "~/assets/js/ace-elements.min.js",
                "~/assets/js/bootstrap.min.js",
                "~/assets/js/bootbox.min.js",
                "~/assets/js/jquery.gritter.min.js",
                "~/assets/js/ace.min.js",
                "~/assets/js/toastr.min.js",
                "~/assets/js/jquery.dataTables.bootstrap.js",
                "~/assets/js/select2.min.js",
                "~/assets/js/date-time/bootstrap-datepicker_ver-8Dec2014.js",
                "~/assets/js/jquery.maskedinput.min.js",
                "~/assets/js/jqGrid/jquery.jqGrid.src.js"
                ));

            //CSS For Layout 
            bundles.Add(new StyleBundle("~/bundles/LayoutCommoncss").Include("~/assets/css/bootstrap.min.css",
                "~/assets/css/font-awesome.min.css",
                "~/assets/css/font-awesome-ie7.min.css",
                "~/assets/css/Icons.css",
                "~/assets/css/jquery.gritter.min.css",
                "~/assets/css/ace.min.css",
                "~/assets/css/ace-fonts.min.css",
                "~/assets/css/toastr.min.css",
                "~/assets/css/select2.min.css",
                "~/assets/css/jquery-ui.min.css",
                "~/assets/css/ui.jqgrid.css",
                "~/assets/css/datepicker.min.css"));

            BundleTable.EnableOptimizations = true;
        }
    }
}
