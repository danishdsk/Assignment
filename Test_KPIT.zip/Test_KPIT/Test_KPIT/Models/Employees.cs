﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Test_KPIT.Models.DataAccess;

namespace Test_KPIT.Models
{
    public class Employees
    {
        #region Properties
        int _ID;
        string _Name;
        int _Age;
        string _Marital_Status; 
        decimal _Salary;
        string _Location;
        string _Action;

        public int ID
        {
            get
            {
                return _ID;
            }

            set
            {
                _ID = value;
            }
        }
        public string Name
        {
            get
            {
                return _Name;
            }

            set
            {
                _Name = value;
            }
        }
        public int Age
        {
            get
            {
                return _Age;
            }

            set
            {
                _Age = value;
            }
        }
        public string Marital_Status
        {
            get
            {
                return _Marital_Status;
            }

            set
            {
                _Marital_Status = value;
            }
        }
        public decimal Salary
        {
            get
            {
                return _Salary;
            }

            set
            {
                _Salary = value;
            }
        }
        public string Location
        {
            get
            {
                return _Location;
            }

            set
            {
                _Location = value;
            }
        }
        public string Action
        {
            get
            {
                return _Action;
            }

            set
            {
                _Action = value;
            }
        }
        
        #endregion

        #region Methods
        public List<Employees> GetEmployees(int ID)
        {

            SqlCommand cmd = new SqlCommand("Get_Employee");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@p_ID", ID));
            DataTable dt = (DataTable)SqlHelper.Execute_Reader(cmd);

            List<Employees> modelList = (dt != null) ? (from s in dt.AsEnumerable()
                                        select new Employees
                                        {
                                            ID = s.Field<int>("ID"),
                                            Name = s.Field<string>("Name"),
                                            Age = s.Field<int>("Age"),
                                            Marital_Status = s.Field<string>("Marital_Status"),
                                            Salary = s.Field<decimal>("Salary"),
                                            Location = s.Field<string>("Location"),
                                            Action = "<button type='button' class='btn btn-minier btn-info' onclick='EditEmp(" + s.Field<int>("ID") + ");'> Edit </button> <button type='button' class='btn btn-minier btn-danger align-center' onclick='DeleteEmp(" + s.Field<int>("ID") + ");' > Delete </button>",
                                        }).ToList() : null;

            return modelList;
        }

        public int SaveEmployee(string Flag)
        {

            SqlCommand cmd = new SqlCommand("Save_Employee");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@p_Flag", Flag));
            cmd.Parameters.Add(new SqlParameter("@p_ID", this.ID));
            cmd.Parameters.Add(new SqlParameter("@P_Name", this.Name ?? ""));
            cmd.Parameters.Add(new SqlParameter("@P_Age", this.Age));
            cmd.Parameters.Add(new SqlParameter("@P_Marital_Status", this.Marital_Status ?? ""));
            cmd.Parameters.Add(new SqlParameter("@p_Salary", this.Salary));
            cmd.Parameters.Add(new SqlParameter("@P_Location", this.Location ?? ""));

            var res = (int)SqlHelper.Execute_Scalar(cmd);
            
            return res;
        }
        #endregion
    }
}