﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Test_KPIT.Models.DataAccess
{
    public class SqlHelper
    {
        static string strConnection = ConfigurationManager.ConnectionStrings["Connection String"].ConnectionString;
        static public object Execute_Reader(SqlCommand cmd)
        {
            SqlConnection conn = null;
            SqlDataReader dr = null;
            conn = new SqlConnection(strConnection);
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandTimeout = 60;
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dr.Close();
            cmd.Dispose();
            conn.Close();
            return dt.AsEnumerable().FirstOrDefault() != null ? dt.AsEnumerable().FirstOrDefault().Table : null;
        }

        static public object Execute_Scalar(SqlCommand cmd)
        {
            SqlConnection conn = null;
            conn = new SqlConnection(strConnection);
            conn.Open();
            cmd.Connection = conn;
            var id = cmd.ExecuteScalar();
            cmd.Dispose();
            conn.Close();
            return id;
        }

        static public object Execute_Non_Query(SqlCommand cmd)
        {
            SqlConnection conn = null;
            conn = new SqlConnection(strConnection);
            conn.Open();
            cmd.Connection = conn;
            var id = cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            return id;
        }

        static public DataSet GetDS(SqlCommand cmd)
        {
            SqlConnection conn = null;
            conn = new SqlConnection(strConnection);
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandTimeout = 60;

            DataSet ds = new DataSet();
            var dataAdapter = new SqlDataAdapter(cmd);
            dataAdapter.Fill(ds);

            dataAdapter.Dispose();
            cmd.Dispose();
            conn.Close();
            return ds;
        }
    }
}