﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Test_KPIT.Models;

namespace Test_KPIT.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetEmployeesList()
        {
            Employees model = new Employees();
            List<Employees> modelTable = model.GetEmployees(0);
            return Json(new { aaData = modelTable }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SaveEmployee(int id = 0)
        {
            Employees model = new Employees();
            if (id > 0)
            {
                model = model.GetEmployees(id).FirstOrDefault();
            }
            return PartialView(model);
        }

        [HttpPost]
        public ActionResult SaveEmployee(Employees model)
        {
            var result = model.SaveEmployee(model.ID > 0 ? "E" : "I");
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DelEmployee(int id)
        {
            Employees model = new Employees();
            model.ID = id;
            var result = model.SaveEmployee("D");
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}